import { serverSupabase } from './supabase';
export async function getSettings() {
  const db = await serverSupabase();
  const { data } = await db.from('site_settings').select('*').eq('id', 1).maybeSingle();
  return data || { artist_name: 'RED HOOD', bio: 'Independent artist. South Tehran DNA.', profile_image: '', logo_image: '', spotify_url: '', soundcloud_url: '', instagram_url: '', youtube_url: '', featured_release_id: null };
}
export async function getReleases(status?: string) {
  const db = await serverSupabase();
  await db.rpc('publish_due_releases');
  let q = db.from('releases').select('*').order('sort_order', { ascending: true }).order('release_date', { ascending: false });
  if (status) q = q.eq('status', status);
  const { data } = await q;
  return data || [];
}
export async function getPages() {
  const db = await serverSupabase();
  const { data } = await db.from('pages').select('*').eq('published', true).order('sort_order');
  return data || [];
}
