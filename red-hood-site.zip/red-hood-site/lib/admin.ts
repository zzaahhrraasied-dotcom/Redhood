import {serverSupabase,isAdminEmail} from './supabase';
import {NextResponse} from 'next/server';
export async function adminDb(){const db=await serverSupabase();const {data:{user}}=await db.auth.getUser();if(!user||!isAdminEmail(user.email))throw new Error('Unauthorized');return db;}
export function fail(e:unknown){return NextResponse.json({error:e instanceof Error?e.message:'Request failed'},{status:e instanceof Error&&e.message==='Unauthorized'?401:400});}
